# Brand — Ecommerce Frontend Design

A pixel-faithful recreation of the B2B ecommerce marketplace homepage using **HTML5**, **Bootstrap 5**, and custom CSS.

---

## 📁 Project Structure

```
ecommerce-frontend-design/
├── assets/
│   └── images/             ← All your image files go here
│       ├── hero-banner.jpg
│       ├── flag-de.png
│       ├── app-store.png
│       ├── google-play.png
│       ├── categories/
│       │   ├── home-outdoor.jpg
│       │   └── electronics.jpg
│       └── products/
│           ├── smartwatch.png
│           ├── laptop.png
│           ├── headphones.png
│           ├── camera.png
│           ├── tshirt.jpg
│           └── ... (all product images)
├── css/
│   └── style.css           ← All custom styles
├── js/
│   └── main.js             ← JS for countdown, search, form interactions
├── index.html              ← Homepage (main page)
├── products.html           ← Products listing page (placeholder)
├── products-detail.html    ← Single product detail page (placeholder)
└── README.md               ← This file
```

---

## 🚀 How to Run

1. Clone or download this project folder
2. Open `index.html` in any modern browser — no build step needed
3. For a better dev experience, use **Live Server** (VS Code extension):
   - Right-click `index.html` → **"Open with Live Server"**

---

## 🖼️ Adding Your Own Images

The project currently uses Unsplash placeholder images (served from the internet). To use your own local images:

### 1. Hero Banner
Place your banner image at:
```
assets/images/hero-banner.jpg
```
Then in `index.html`, find the `<img class="banner-img">` tag and update:
```html
<img src="assets/images/hero-banner.jpg" class="banner-img" alt="Banner" />
```
**Recommended size:** 900 × 360px

---

### 2. Deal Product Images
Place images at `assets/images/products/` and update each `<img>` inside `.deal-card`:
```html
<img src="assets/images/products/smartwatch.png" alt="Smart watches" />
```
**Recommended size:** 160 × 120px (PNG with transparent background preferred)

---

### 3. Category Section Images

**Home & Outdoor side banner:**
```
assets/images/categories/home-outdoor.jpg
```
Update the `<img>` inside `.category-banner-side.home-outdoor`:
```html
<img src="assets/images/categories/home-outdoor.jpg" alt="Home and outdoor" />
```

**Electronics side banner:**
```
assets/images/categories/electronics.jpg
```
**Recommended size:** 180 × 100px

---

### 4. Category Grid Product Images
Place small product thumbnails at `assets/images/products/` and update each `.cat-product-item img`:
```html
<img src="assets/images/products/sofa.png" alt="Sofa & chair" />
```
**Recommended size:** 80 × 80px (PNG with transparent background preferred)

---

### 5. Recommended Items Grid
Place product card images at `assets/images/products/` and update `.product-card img`:
```html
<img src="assets/images/products/tshirt.jpg" alt="T-shirts" />
```
**Recommended size:** 240 × 200px

---

### 6. Service Section Images
Place service images at `assets/images/services/`:
```html
<img src="assets/images/services/industry-hubs.jpg" alt="Source from Industry Hubs" />
```
**Recommended size:** 400 × 140px

---

### 7. Country Flags
To use real flag images instead of emoji:
```
assets/images/flags/ae.png   (Arabic Emirates)
assets/images/flags/us.png   (United States)
...
```
Replace the emoji spans in `index.html`:
```html
<!-- Before -->
<span style="font-size:18px;">🇦🇪</span>

<!-- After -->
<img src="assets/images/flags/ae.png" class="flag-img" alt="UAE" />
```
**Recommended size:** 22 × 16px

---

### 8. App Store Badges
Download official badges and place at:
```
assets/images/app-store.png
assets/images/google-play.png
```
Update in `index.html` footer:
```html
<img src="assets/images/app-store.png" alt="App Store" style="height:38px;" />
<img src="assets/images/google-play.png" alt="Google Play" style="height:38px;" />
```

---

## 🎨 Color Scheme (CSS Variables)

Defined in `css/style.css` under `:root`:

| Variable        | Color     | Usage                        |
|-----------------|-----------|------------------------------|
| `--primary`     | `#0d6efd` | Buttons, links, accents      |
| `--primary-dark`| `#0a58ca` | Hover state for primary      |
| `--orange`      | `#fa8232` | Promo banner                 |
| `--teal`        | `#47b2e4` | Promo banner, quote section  |
| `--text-dark`   | `#1c1c1c` | Main body text               |
| `--text-muted`  | `#8b96a5` | Secondary text               |
| `--border`      | `#dee2e7` | Card borders, dividers       |
| `--bg-light`    | `#f7fafc` | Page background              |
| `--danger`      | `#fa3434` | Discount badges              |
| `--success`     | `#00b517` | Positive badges              |

---

## 🧩 Technologies Used

- **HTML5** — semantic markup
- **Bootstrap 5.3** — grid, utilities, responsive layout
- **Bootstrap Icons 1.11** — icon set
- **Google Fonts — Inter** — clean, modern typeface
- **Custom CSS** — layout overrides, component styles
- **Vanilla JS** — countdown timer, form interactions

---

## 📄 Pages

| File                  | Status      | Description                        |
|-----------------------|-------------|------------------------------------|
| `index.html`          | ✅ Complete  | Full homepage with all sections    |
| `products.html`       | 🔲 Placeholder | Product listing / category page |
| `products-detail.html`| 🔲 Placeholder | Single product detail page      |

---

## 💡 Tips

- All placeholder images use **Unsplash** URLs and require an internet connection. Replace them with local images for production.
- The countdown timer persists via `localStorage`. Clear browser storage to reset it.
- Adjust the `--primary` CSS variable to quickly rebrand the entire site.

---

© 2023 Brand Ecommerce. Built for internship assignment.
